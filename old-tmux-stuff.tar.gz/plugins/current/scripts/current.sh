#!/bin/env bash
DEBUG=0
CUR_SHELL=
INFO=""
[[ "$1" =~ ^-[Yy]$ ]] && DEBUG=1 
SHELL_PID=$(tmux display -p "#{pane_pid}")
CHILD_PID=$(pgrep -P $SHELL_PID -l)
CUR_SHELL="$(ps -q $SHELL_PID -o comm=)"
if [[! $(wc -l <<< "$CHILD_PID") -ne 1 || ! "${CHILD_PID##* }" = "nvim" ]]; then
  OUT="$(tmux display -p "#{W}")"
else
  CMD="${CHILD_PID##* }"
  CHILD_PID="$( pgrep -P $SHELL_PID )"
  FILE=$( ps $CHILD_PID | grep nvim | awk '{print $6}' )  
  OUT="$(basename $FILE)"
fi
if [[ $DEBUG -eq 1 ]]; then
  tmux display -p "run plugin: \"current\""
  tmux display -p "DEBUG:      $DEBUG"
  tmux display -p "SHELL_PID:  $SHELL_PID"
  tmux display -p "CHILD_PID:  $CHILD_PID"
  tmux display -p "CUR_SHELL:  $CUR_SHELL"
  tmux display -p "CMD:        $CMD"
  tmux display -p "FILE:       $FILE"
fi
tmux set -g @nvim_current_document "$OUT"
tmux refresh-client
#tmux source-file "$SOURCEFILE"
