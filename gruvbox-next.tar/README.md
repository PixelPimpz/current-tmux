# Gruvbox-Next
Hopefully a snazzy, fresh gruvbox-based theme for Tmux. Derived from the gruvbox-dark color set and featuring a modular status bar with visuals designed to convey all the info you want without clutter or confusing clusters  of mostly useless data.

This is my first Tmux project and it's as much a sandbox playspace for me to try different hair-brained ideas while I learn this absolutely bonkers system of configuration.

Its new. I'm new. I have only a vague idea of what i want it to be in the end. But for this project the ends are far less compelling for me than the path of proficiency with Tmux.

This README will reflect the changes and additions that gtet made mostly as I make them. I'm open to any and all useful comments, criticisms and guidance so speak up!

Thanks!
